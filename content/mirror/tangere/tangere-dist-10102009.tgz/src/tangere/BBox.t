
/*
 *  Copyright 2009 Grove City College
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

#ifndef tangere_BBox_t
#define tangere_BBox_t

#include <iostream>
using std::istream;
using std::ostream;

#include <Math/Math.h>

#include <tangere/Flags.h>
#include <tangere/Ray.t>

namespace tangere
{

  //////////////////////////////////////////////////////////////////////////////
  // Using declarations

  using Math::Point;
  using Math::Vector;

  //////////////////////////////////////////////////////////////////////////////
  // Class template definition

  template<typename T>
  struct BBox
  {
    inline BBox()
    {
      bounds[0] = Math::Point<T>::Max;
      bounds[1] = Math::Point<T>::Min;
    }

    inline ~BBox()
    {
      //no-op
    }

    inline bool intersect(T& thit, const Ray<T>& ray) const
    {
      const Point<T>& org  = ray.org();
      const T*        inv  = ray.inv();
      const uint*     sign = ray.sign();

      const T tminX = (bounds[  sign[0]][0] - org[0])*inv[0];
      const T tmaxY = (bounds[1-sign[1]][1] - org[1])*inv[1];

      if (tminX > tmaxY)
        return false;

      const T tmaxX = (bounds[1-sign[0]][0] - org[0])*inv[0];
      const T tminY = (bounds[  sign[1]][1] - org[1])*inv[1];

      if (tmaxX < tminY)
        return false;

      T tmin = (tminX > tminY ? tminX : tminY);
      const T tmaxZ = (bounds[1-sign[2]][2] - org[2])*inv[2];

      if (tmin > tmaxZ)
        return false;

      T tmax = (tmaxX < tmaxY ? tmaxX : tmaxY);
      const T tminZ = (bounds[  sign[2]][2] - org[2])*inv[2];
    
      if (tmax < tminZ)
        return false;

      tmin = (tmin > tminZ ? tmin : tminZ);
      tmax = (tmax < tmaxZ ? tmax : tmaxZ);

      if (tmin <= tmax)
      {
        thit = tmin;
        return true;
      }

      return false;
    }

    inline void extend(const BBox<T>& b)
    {
      bounds[0] = Min(b.bounds[0], bounds[0]);
      bounds[1] = Max(b.bounds[1], bounds[1]);
    }

    inline void extend(const Point<T>& p)
    {
      bounds[0] = Min(p, bounds[0]);
      bounds[1] = Max(p, bounds[1]);
    }

    inline void extend(const Vector<T>& v)
    {
      bounds[0] = Min(Point<T>(v), bounds[0]);
      bounds[1] = Max(Point<T>(v), bounds[1]);
    }

    inline void reset()
    {
      bounds[0] = Math::Point<T>::Max;
      bounds[1] = Math::Point<T>::Min;
    }

    inline Point<T> center() const
    {
      return (bounds[0] + bounds[1])/2;
    }

    inline Vector<T> diagonal() const
    {
      return (bounds[1] - bounds[0]);
    }

    ////////////////////////////////////////////////////////////////////////////
    // Stream I/O

    friend istream& operator>>(istream& in, BBox<T>& b)
    {
      in >> b.bounds[0] >> b.bounds[1];
      return in;
    }

    friend ostream& operator<<(ostream& out, const BBox<T>& b)
    {
      out << b.bounds[0] << ' ' << b.bounds[1];
      return out;
    }

    Point<T> bounds[2];
  };

  //////////////////////////////////////////////////////////////////////////////
  // Template specialization - BBox<int>

  template<>
  inline bool BBox<int>::intersect(int& t, const Ray<int>& ray) const
  {
    const Point<int>& org  = ray.org();
    const int64*      inv  = ray.inv();
    const uint*       sign = ray.sign();

    const int64 tminX = (int64(bounds[  sign[0]][0] - org[0]) >> dBits)*inv[0];
    const int64 tmaxY = (int64(bounds[1-sign[1]][1] - org[1]) >> dBits)*inv[1];

    if (tminX > tmaxY)
      return false;

    const int64 tmaxX = (int64(bounds[1-sign[0]][0] - org[0]) >> dBits)*inv[0];
    const int64 tminY = (int64(bounds[  sign[1]][1] - org[1]) >> dBits)*inv[1];

    if (tmaxX < tminY)
      return false;

          int64 tmin  = (tminX > tminY ? tminX : tminY);
    const int64 tmaxZ = (int64(bounds[1-sign[2]][2] - org[2]) >> dBits)*inv[2];

    if (tmin > tmaxZ)
      return false;

          int64 tmax  = (tmaxX < tmaxY ? tmaxX : tmaxY);
    const int64 tminZ = (int64(bounds[  sign[2]][2] - org[2]) >> dBits)*inv[2];

    if (tmax < tminZ)
      return false;

    tmin = (tmin > tminZ ? tmin : tminZ);
    tmax = (tmax < tmaxZ ? tmax : tmaxZ);

    if (tmin <= tmax)
    {
      tmin >>= cdDiff;

      if (tmin > INT_MAX || tmin < -INT_MAX)
        return false;

      t = int(tmin);
      return true;
    }

    return false;
  }

} // namespace tangere

#endif // tangere_BBox_h
